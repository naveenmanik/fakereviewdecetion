# The files in this repo are all created using the code in flipkartreviews.py file
